package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class OpportunitiesFragment extends Fragment {

    private RecyclerView rvJobs;
    private OpportunitiesAdapter adapter;
    private List<Jobmodel> jobList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_opportunities, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvJobs = view.findViewById(R.id.rvJobs);
        rvJobs.setLayoutManager(new LinearLayoutManager(getContext()));

        jobList = new ArrayList<>();
        jobList.add(new Jobmodel("Software Intern", "TechCorp", "Active", 45));
        jobList.add(new Jobmodel("Data Analyst", "DataFlow", "Active", 32));
        jobList.add(new Jobmodel("UX Designer", "Creative", "Closed", 18));
        jobList.add(new Jobmodel("Marketing Intern", "GrowthCo", "Draft", 0));

        adapter = new OpportunitiesAdapter(jobList);
        rvJobs.setAdapter(adapter);
    }
}
