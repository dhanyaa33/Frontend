package com.example.surepath;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class OnboardingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        TextView btnNext = findViewById(R.id.btnNext);
        TextView tvSkip = findViewById(R.id.tvSkip);

        btnNext.setOnClickListener(v -> {
            Intent intent = new Intent(OnboardingActivity.this, SkillOnboardingActivity.class);
            startActivity(intent);
            finish();
        });

        tvSkip.setOnClickListener(v -> {
            Intent intent = new Intent(OnboardingActivity.this,SkillOnboardingActivity.class);
            startActivity(intent);
            finish();
        });
    }
}