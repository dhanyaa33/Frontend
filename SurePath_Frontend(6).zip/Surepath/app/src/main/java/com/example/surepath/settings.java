package com.example.surepath;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class settings extends Fragment {

    private Switch switchDark, switchNotif;

    public settings() {}

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {

        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        switchDark = view.findViewById(R.id.switchDarkMode);
        switchNotif = view.findViewById(R.id.switchNotifications);

        SharedPreferences prefs =
                requireContext().getSharedPreferences("settings", 0);

        switchDark.setChecked(prefs.getBoolean("dark_mode", true));
        switchNotif.setChecked(prefs.getBoolean("notifications", true));

        switchDark.setOnCheckedChangeListener((b, checked) -> {
            prefs.edit().putBoolean("dark_mode", checked).apply();
            Toast.makeText(getContext(),
                    checked ? "Dark mode ON" : "Dark mode OFF",
                    Toast.LENGTH_SHORT).show();
        });

        switchNotif.setOnCheckedChangeListener((b, checked) -> {
            prefs.edit().putBoolean("notifications", checked).apply();
            Toast.makeText(getContext(),
                    checked ? "Notifications ON" : "Notifications OFF",
                    Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.btnLogout).setOnClickListener(v ->
                Toast.makeText(getContext(), "Logged Out", Toast.LENGTH_SHORT).show()
        );

        view.findViewById(R.id.btnDelete).setOnClickListener(v ->
                Toast.makeText(getContext(), "Account Deleted", Toast.LENGTH_SHORT).show()
        );

        RelativeLayout btnHelp = view.findViewById(R.id.btnHelp);
        btnHelp.setOnClickListener(v -> {
            FragmentTransaction ft = getParentFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_container, new HelpSupportFragment());
            ft.addToBackStack(null);
            ft.commit();
        });

        RelativeLayout btnPrivacy = view.findViewById(R.id.btnPrivacy);
        btnPrivacy.setOnClickListener(v -> {
            FragmentTransaction ft = getParentFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_container, new TermsPrivacyFragment());
            ft.addToBackStack(null);
            ft.commit();
        });

        return view;
    }
}
