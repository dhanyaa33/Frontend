package com.example.surepath.model;

public class StudentRegisterRequest {

    public String name;
    public String email;
    public String password;
    public String[] skills;
    public String district_type;
    public String category;
    public String location;

    // ✅ Proper constructor (FIXES your error)
    public StudentRegisterRequest(
            String name,
            String email,
            String password,
            String[] skills,
            String district_type,
            String category,
            String location
    ) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.skills = skills;
        this.district_type = district_type;
        this.category = category;
        this.location = location;
    }
}
