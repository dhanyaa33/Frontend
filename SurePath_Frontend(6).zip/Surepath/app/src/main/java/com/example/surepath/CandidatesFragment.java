package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CandidatesFragment extends Fragment {

    private RecyclerView rvCandidates;
    private CandidateAdapter adapter;
    private List<Candidate> candidateList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_candidates, container, false);

        rvCandidates = view.findViewById(R.id.rvCandidates);
        rvCandidates.setLayoutManager(new LinearLayoutManager(getContext()));

        candidateList = new ArrayList<>();
        candidateList.add(new Candidate("John Doe", "Computer Science Student", 95, Arrays.asList("Python", "React"), "", "", ""));
        candidateList.add(new Candidate("Jane Smith", "Data Science Student", 88, Arrays.asList("Python", "Problem Solving"), "", "", ""));
        candidateList.add(new Candidate("Peter Jones", "Software Engineering Student", 82, Arrays.asList("React", "Problem Solving"), "", "", ""));

        adapter = new CandidateAdapter(candidateList);
        rvCandidates.setAdapter(adapter);

        MaterialButton btnFilter = view.findViewById(R.id.btnFilter);
        btnFilter.setOnClickListener(v -> {
            FilterBottomSheetFragment bottomSheet = new FilterBottomSheetFragment();
            bottomSheet.show(getParentFragmentManager(), bottomSheet.getTag());
        });

        return view;
    }
}
