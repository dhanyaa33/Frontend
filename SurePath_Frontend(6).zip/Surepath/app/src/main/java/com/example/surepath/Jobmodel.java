package com.example.surepath;

import java.io.Serializable;

public class Jobmodel implements Serializable {

    private String title;
    private String company;
    private String status;
    private int applicants;

    public Jobmodel(String title, String company, String status, int applicants) {
        this.title = title;
        this.company = company;
        this.status = status;
        this.applicants = applicants;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getApplicants() {
        return applicants;
    }

    public void setApplicants(int applicants) {
        this.applicants = applicants;
    }
}
