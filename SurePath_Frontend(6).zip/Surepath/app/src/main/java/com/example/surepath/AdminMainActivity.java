package com.example.surepath;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AdminMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main);

        BottomNavigationView bottomNav = findViewById(R.id.admin_bottom_nav);
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();
            if (itemId == R.id.admin_nav_dashboard) {
                selectedFragment = new AdminDashboardFragment();
            } else if (itemId == R.id.admin_nav_candidates) {
                selectedFragment = new CandidatesFragment();
            } else if (itemId == R.id.admin_nav_apps) {
                selectedFragment = new AdminAppsFragment();
            } else if (itemId == R.id.admin_nav_search) {
                selectedFragment = new AdminSearchFragment();
            } else if (itemId == R.id.admin_nav_settings) {
                selectedFragment = new AdminSettingsFragment();
            }

            if (selectedFragment != null) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.admin_fragment_container, selectedFragment);
                transaction.commit();
            }
            return true;
        });

        // Set default fragment
        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.admin_nav_dashboard);
        }
    }
}
