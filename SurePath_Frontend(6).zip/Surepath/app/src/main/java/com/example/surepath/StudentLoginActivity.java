package com.example.surepath;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StudentLoginActivity extends AppCompatActivity {

    AutoCompleteTextView etEmail;
    EditText etPassword;
    Button btnLogin;
    TextView tvForgot, tvSignup;
    ImageView btnBack;

    private static final String[] EMAIL_DOMAINS = new String[] {
        "gmail.com", "yahoo.com", "hotmail.com", "outlook.com"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvForgot = findViewById(R.id.tvForgot);
        tvSignup = findViewById(R.id.tvSignup);
        btnBack = findViewById(R.id.btnBack);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, EMAIL_DOMAINS);
        etEmail.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            } else {
                // TEMP: Replace with backend API call
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(
                        StudentLoginActivity.this,
                        MainActivity.class
                ));
            }
        });

        tvForgot.setOnClickListener(v ->
                Toast.makeText(this, "Forgot Password clicked", Toast.LENGTH_SHORT).show()
        );

        tvSignup.setOnClickListener(v ->
                Toast.makeText(this, "Sign Up clicked", Toast.LENGTH_SHORT).show()
        );
    }
}
