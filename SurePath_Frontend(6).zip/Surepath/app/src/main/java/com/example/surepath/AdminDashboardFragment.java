package com.example.surepath;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import java.util.ArrayList;
import java.util.List;

public class AdminDashboardFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_dashboard, container, false);

        // Animate the whole fragment
        Animation slideIn = AnimationUtils.loadAnimation(getContext(), R.anim.slide_in_up);
        view.startAnimation(slideIn);

        // --- Dynamic Cards ---
        TextView tvTotalInterns = view.findViewById(R.id.tvTotalInterns);
        TextView tvNewApplications = view.findViewById(R.id.tvNewApplications);
        TextView tvTotalPlaced = view.findViewById(R.id.tvTotalPlaced);

        // You can update these values from your backend
        tvTotalInterns.setText("1,200");
        tvNewApplications.setText("50");
        tvTotalPlaced.setText("800");

        // --- Bar Chart ---
        BarChart barChart = view.findViewById(R.id.barChart);
        setupBarChart(barChart);

        // --- Recent Activity ---
        RecyclerView rvRecentActivity = view.findViewById(R.id.rvRecentActivity);
        rvRecentActivity.setLayoutManager(new LinearLayoutManager(getContext()));

        List<RecentActivity> activityList = new ArrayList<>();
        activityList.add(new RecentActivity(R.drawable.ic_person, "New Application", "John Doe applied for Software Intern"));
        activityList.add(new RecentActivity(R.drawable.ic_person, "New Application", "Jane Smith applied for Data Analyst"));

        RecentActivityAdapter adapter = new RecentActivityAdapter(activityList);
        rvRecentActivity.setAdapter(adapter);

        // Staggered Animations
        Animation cardAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.scale_in);
        view.findViewById(R.id.tvWelcome).startAnimation(cardAnimation);
        view.findViewById(R.id.tvTotalInterns).startAnimation(cardAnimation);
        view.findViewById(R.id.tvNewApplications).startAnimation(cardAnimation);
        view.findViewById(R.id.tvTotalPlaced).startAnimation(cardAnimation);
        barChart.startAnimation(cardAnimation);
        rvRecentActivity.startAnimation(cardAnimation);

        return view;
    }

    private void setupBarChart(BarChart barChart) {
        List<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(0f, 30f));
        entries.add(new BarEntry(1f, 80f));
        entries.add(new BarEntry(2f, 60f));
        entries.add(new BarEntry(3f, 50f));
        entries.add(new BarEntry(4f, 70f));

        BarDataSet set = new BarDataSet(entries, "Application Statistics");

        // Use the custom gradient drawable
        Drawable chartGradient = ContextCompat.getDrawable(getContext(), R.drawable.chart_gradient);
        set.setBarBorderWidth(1f);
        set.setBarBorderColor(Color.TRANSPARENT);
        set.setGradientColor(Color.parseColor("#1E293B"), Color.parseColor("#2DD4BF"));


        ArrayList<IBarDataSet> dataSets = new ArrayList<>();
        dataSets.add(set);

        BarData data = new BarData(dataSets);
        data.setBarWidth(0.9f); // set custom bar width
        barChart.setData(data);
        barChart.setFitBars(true); // make the x-axis fit exactly all bars
        barChart.getDescription().setEnabled(false);
        barChart.getAxisRight().setEnabled(false);
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getXAxis().setTextColor(Color.WHITE);
        barChart.getAxisLeft().setTextColor(Color.WHITE);
        barChart.getLegend().setTextColor(Color.WHITE);
        barChart.invalidate(); // refresh
    }
}
