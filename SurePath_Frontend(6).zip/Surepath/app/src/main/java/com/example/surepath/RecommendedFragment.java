package com.example.surepath;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class RecommendedFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_recommended, container, false);

        RecyclerView recycler = v.findViewById(R.id.recyclerJobs);
        recycler.setLayoutManager(new LinearLayoutManager(getContext()));

        List<Jobmodel> jobs = new ArrayList<>();
        jobs.add(new Jobmodel("Software Intern", "TechCorp Inc.", "Active", 95));
        jobs.add(new Jobmodel("Data Analyst Intern", "DataFlow Systems", "Active", 88));
        jobs.add(new Jobmodel("UI/UX Designer", "Creative Studio", "Closed", 82));
        jobs.add(new Jobmodel("Backend Developer", "ServerSide Ltd", "Draft", 78));

        recycler.setAdapter(new JobAdapter(jobs));

        return v;
    }
}
