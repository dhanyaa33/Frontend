package com.example.surepath.model;

public class StudentLoginRequest {
    public String email;
    public String password;
}
