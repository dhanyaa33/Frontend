package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.List;

public class CandidateDetailsFragment extends Fragment {

    private Candidate candidate;

    public static CandidateDetailsFragment newInstance(Candidate candidate) {
        CandidateDetailsFragment fragment = new CandidateDetailsFragment();
        Bundle args = new Bundle();
        // Note: You might want to pass the candidate's ID and fetch the data from a database
        // instead of passing the whole object. For simplicity, we'll pass the whole object here.
        args.putSerializable("candidate", (java.io.Serializable) candidate);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            candidate = (Candidate) getArguments().getSerializable("candidate");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_candidate_details, container, false);

        ImageView btnBack = view.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> getParentFragmentManager().popBackStack());

        if (candidate != null) {
            TextView tvCandidateName = view.findViewById(R.id.tvCandidateName);
            TextView tvCandidateRole = view.findViewById(R.id.tvCandidateRole);
            TextView tvMatchScore = view.findViewById(R.id.tvMatchScore);
            ProgressBar progressBar = view.findViewById(R.id.progressBar);
            TextView tvBio = view.findViewById(R.id.tvBio);
            ChipGroup cgSkills = view.findViewById(R.id.cgSkills);
            TextView tvEmail = view.findViewById(R.id.tvEmail);
            TextView tvPhone = view.findViewById(R.id.tvPhone);
            Button btnAssignJob = view.findViewById(R.id.btnAssignJob);

            tvCandidateName.setText(candidate.getName());
            tvCandidateRole.setText(candidate.getRole());
            tvMatchScore.setText(String.format("%d%%", candidate.getMatchScore()));
            progressBar.setProgress(candidate.getMatchScore());
            tvBio.setText(candidate.getBio());
            tvEmail.setText(candidate.getEmail());
            tvPhone.setText(candidate.getPhone());

            // Dynamically add chips for skills
            for (String skill : candidate.getSkills()) {
                Chip chip = new Chip(getContext());
                chip.setText(skill);
                cgSkills.addView(chip);
            }

            btnAssignJob.setOnClickListener(v -> {
                // TODO: Implement your assign job logic
                Toast.makeText(getContext(), "Job assigned to " + candidate.getName(), Toast.LENGTH_SHORT).show();
            });

            // Staggered Animations
            Animation slideIn = AnimationUtils.loadAnimation(getContext(), R.anim.slide_in_up);
            view.findViewById(R.id.tvCandidateName).startAnimation(slideIn);
            view.findViewById(R.id.tvCandidateRole).startAnimation(slideIn);
            view.findViewById(R.id.tvMatchScore).startAnimation(slideIn);
            view.findViewById(R.id.progressBar).startAnimation(slideIn);
            view.findViewById(R.id.tvBio).startAnimation(slideIn);
            view.findViewById(R.id.cgSkills).startAnimation(slideIn);
            view.findViewById(R.id.tvEmail).startAnimation(slideIn);
            view.findViewById(R.id.tvPhone).startAnimation(slideIn);
            view.findViewById(R.id.btnAssignJob).startAnimation(slideIn);
        }

        return view;
    }
}
