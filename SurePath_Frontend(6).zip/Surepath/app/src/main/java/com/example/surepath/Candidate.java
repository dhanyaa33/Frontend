package com.example.surepath;

import java.util.List;

public class Candidate {
    private String name;
    private String role;
    private int matchScore;
    private List<String> skills;
    private String bio;
    private String email;
    private String phone;

    public Candidate(String name, String role, int matchScore, List<String> skills, String bio, String email, String phone) {
        this.name = name;
        this.role = role;
        this.matchScore = matchScore;
        this.skills = skills;
        this.bio = bio;
        this.email = email;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public int getMatchScore() {
        return matchScore;
    }

    public List<String> getSkills() {
        return skills;
    }

    public String getBio() {
        return bio;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }
}
