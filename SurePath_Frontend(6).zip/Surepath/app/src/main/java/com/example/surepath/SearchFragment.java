package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

public class SearchFragment extends Fragment {

    private static final String[] KEYWORDS = new String[] {
            "Software Engineer", "Product Manager", "UI/UX Designer", "Data Scientist", "Marketing Manager"
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        // --- Toolbar Setup ---
        // We will use the Toolbar as a standalone view and not set it as the support action bar
        // to avoid conflicts with the activity's NoActionBar theme.
        Toolbar toolbar = view.findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(v -> {
                // Navigate back to the previous screen
                if (getParentFragmentManager() != null) {
                    getParentFragmentManager().popBackStack();
                }
            });
        }

        // --- Autocomplete Setup (Safe) ---
        AutoCompleteTextView searchEditText = view.findViewById(R.id.searchEditText);
        if (searchEditText != null && getContext() != null) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                    android.R.layout.simple_dropdown_item_1line, KEYWORDS);
            searchEditText.setAdapter(adapter);
        }

        // --- Animation Setup (Safe) ---
        if (getContext() != null) {
            Animation slideIn = AnimationUtils.loadAnimation(getContext(), R.anim.slide_in_up);
            // Animate views only if they exist
            animateView(view.findViewById(R.id.searchEditText), slideIn);
            animateView(view.findViewById(R.id.sectorsHeader), slideIn);
            animateView(view.findViewById(R.id.sectorsChipGroup), slideIn);
            animateView(view.findViewById(R.id.locationHeader), slideIn);
            animateView(view.findViewById(R.id.locationChipGroup), slideIn);
            animateView(view.findViewById(R.id.durationHeader), slideIn);
            animateView(view.findViewById(R.id.durationChipGroup), slideIn);
        }

        return view;
    }

    private void animateView(View view, Animation animation) {
        if (view != null && animation != null) {
            view.startAnimation(animation);
        }
    }
}
