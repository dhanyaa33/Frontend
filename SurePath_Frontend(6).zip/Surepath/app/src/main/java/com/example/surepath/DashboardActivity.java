package com.example.surepath;

import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {

    TextView tvApplied, tvShortlisted;
    RecyclerView rvInterviews;
    CardView govSchemesCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvApplied = findViewById(R.id.tvApplied);
        tvShortlisted = findViewById(R.id.tvShortlisted);
        rvInterviews = findViewById(R.id.rvInterviews);
        govSchemesCard = findViewById(R.id.govSchemesCard);

        // Animations
        tvApplied.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale_in));
        tvShortlisted.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale_in));

        // RecyclerView
        rvInterviews.setLayoutManager(new LinearLayoutManager(this));
        rvInterviews.setAdapter(new InterviewAdapter(getDummyData()));

        govSchemesCard.setOnClickListener(v -> {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(android.R.id.content, new GovernmentSchemesFragment());
            ft.addToBackStack(null);
            ft.commit();
        });
    }

    private ArrayList<String> getDummyData() {
        ArrayList<String> list = new ArrayList<>();
        list.add("FinTech Solutions — Tomorrow 10:00 AM");
        list.add("DataSystems Ltd — Fri, 24 Oct, 2:00 PM");
        return list;
    }
}
