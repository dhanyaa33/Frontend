package com.example.surepath;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

public class OpportunitiesAdapter extends RecyclerView.Adapter<OpportunitiesAdapter.ViewHolder> {

    private final List<Jobmodel> list;

    public OpportunitiesAdapter(List<Jobmodel> list) {
        this.list = list;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, company, status, applicants;

        ViewHolder(View v) {
            super(v);
            title = v.findViewById(R.id.tvJobTitle);
            company = v.findViewById(R.id.tvCompany);
            status = v.findViewById(R.id.tvStatus);
            applicants = v.findViewById(R.id.tvApplicants);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_job, parent, false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int p) {
        Jobmodel m = list.get(p);
        h.title.setText(m.getTitle());
        h.company.setText(m.getCompany());
        h.status.setText(m.getStatus());
        h.applicants.setText(String.format(Locale.getDefault(), "%d Applicants", m.getApplicants()));

        switch (m.getStatus()) {
            case "Active":
                h.status.setBackgroundColor(Color.parseColor("#10B981"));
                break;
            case "Closed":
                h.status.setBackgroundColor(Color.parseColor("#EF4444"));
                break;
            case "Draft":
                h.status.setBackgroundColor(Color.parseColor("#6B7280"));
                break;
        }

        h.itemView.setOnClickListener(v -> {
            AppCompatActivity activity = (AppCompatActivity) v.getContext();
            AdminOpportunityDetailsFragment fragment = new AdminOpportunityDetailsFragment();
            Bundle bundle = new Bundle();
            bundle.putSerializable("job", m);
            fragment.setArguments(bundle);
            activity.getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragment) // Assuming you have a container with this ID
                    .addToBackStack(null)
                    .commit();
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
