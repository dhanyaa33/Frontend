package com.example.surepath;

public class Scheme {
    private String schemeName;
    private String ministry;
    private String description;
    private String status;

    public Scheme(String schemeName, String ministry, String description, String status) {
        this.schemeName = schemeName;
        this.ministry = ministry;
        this.description = description;
        this.status = status;
    }

    public String getSchemeName() {
        return schemeName;
    }

    public String getMinistry() {
        return ministry;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }
}
