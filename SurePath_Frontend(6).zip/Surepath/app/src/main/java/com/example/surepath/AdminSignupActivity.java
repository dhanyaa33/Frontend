package com.example.surepath;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminSignupActivity extends AppCompatActivity {

    EditText etEmail, etOrgName, etOrgId, etPassword;
    Button btnRequestAccess;
    TextView tvLogin;
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_signup);

        etEmail = findViewById(R.id.etEmail);
        etOrgName = findViewById(R.id.etOrgName);
        etOrgId = findViewById(R.id.etOrgId);
        etPassword = findViewById(R.id.etPassword);
        btnRequestAccess = findViewById(R.id.btnRequestAccess);
        tvLogin = findViewById(R.id.tvLogin);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        btnRequestAccess.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String orgName = etOrgName.getText().toString().trim();
            String orgId = etOrgId.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || orgName.isEmpty() || orgId.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            } else {
                // TODO: Implement your sign-up logic here
                Toast.makeText(this, "Access requested", Toast.LENGTH_SHORT).show();
            }
        });

        tvLogin.setOnClickListener(v -> {
            // TODO: Navigate to your login screen
            Toast.makeText(this, "Navigate to login", Toast.LENGTH_SHORT).show();
        });
    }
}
