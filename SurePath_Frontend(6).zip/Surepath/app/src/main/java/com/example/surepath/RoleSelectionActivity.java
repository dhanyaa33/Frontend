package com.example.surepath;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class RoleSelectionActivity extends AppCompatActivity {

    ImageView cardStudent, cardAdmin, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_role);

        cardStudent = findViewById(R.id.cardStudent);
        cardAdmin = findViewById(R.id.cardAdmin);
        btnBack = findViewById(R.id.btnBack);

        // Student click → Student flow
        cardStudent.setOnClickListener(v -> {
            Intent intent = new Intent(
                    RoleSelectionActivity.this,
                    StudentLoginActivity.class
            );
            startActivity(intent);
        });

        // Admin click → Admin flow
        cardAdmin.setOnClickListener(v -> {
            Intent intent = new Intent(
                    RoleSelectionActivity.this,
                    AdminLoginActivity.class
            );
            startActivity(intent);
        });

        btnBack.setOnClickListener(v -> finish());
    }
}