package com.example.surepath;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

public class RecentApplicantsAdapter extends RecyclerView.Adapter<RecentApplicantsAdapter.ViewHolder> {

    private final List<RecentApplicantModel> list;

    public RecentApplicantsAdapter(List<RecentApplicantModel> list) {
        this.list = list;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, matchScore;
        Button viewButton;

        ViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.tvApplicantName);
            matchScore = v.findViewById(R.id.tvMatchScore);
            viewButton = v.findViewById(R.id.btnView);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_recent_applicant, parent, false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int p) {
        RecentApplicantModel m = list.get(p);
        h.name.setText(m.getName());
        h.matchScore.setText(String.format(Locale.getDefault(), "%d%% Match Score", m.getMatchScore()));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
