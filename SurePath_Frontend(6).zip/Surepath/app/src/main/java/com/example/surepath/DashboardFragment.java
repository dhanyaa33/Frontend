package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DashboardFragment extends Fragment {

    TextView tvApplied, tvShortlisted;
    RecyclerView rvInterviews;
    CardView govSchemesCard;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_dashboard, container, false);

        tvApplied = view.findViewById(R.id.tvApplied);
        tvShortlisted = view.findViewById(R.id.tvShortlisted);
        rvInterviews = view.findViewById(R.id.rvInterviews);
        govSchemesCard = view.findViewById(R.id.govSchemesCard);

        // Animations
        if (getContext() != null) {
            tvApplied.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.scale_in));
            tvShortlisted.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.scale_in));
        }

        // RecyclerView
        rvInterviews.setLayoutManager(new LinearLayoutManager(getContext()));
        rvInterviews.setAdapter(new InterviewAdapter(getDummyData()));

        govSchemesCard.setOnClickListener(v -> {
            FragmentTransaction ft = getParentFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_container, new GovernmentSchemesFragment());
            ft.addToBackStack(null);
            ft.commit();
        });

        return view;
    }

    private ArrayList<String> getDummyData() {
        ArrayList<String> list = new ArrayList<>();
        list.add("FinTech Solutions — Tomorrow 10:00 AM");
        list.add("DataSystems Ltd — Fri, 24 Oct, 2:00 PM");
        return list;
    }
}
