package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AdminSettingsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_settings, container, false);

        // Add click listeners for all the settings items
        view.findViewById(R.id.rlEditProfile).setOnClickListener(v -> {
            // TODO: Navigate to the edit profile screen
            Toast.makeText(getContext(), "Edit Profile clicked", Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.rlManageUsers).setOnClickListener(v -> {
            // TODO: Navigate to the manage users screen
            Toast.makeText(getContext(), "Manage Users clicked", Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.rlChangePassword).setOnClickListener(v -> {
            // TODO: Navigate to the change password screen
            Toast.makeText(getContext(), "Change Password clicked", Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.rlArchiveInterns).setOnClickListener(v -> {
            // TODO: Implement your archive logic
            Toast.makeText(getContext(), "Archive All Interns clicked", Toast.LENGTH_SHORT).show();
        });

        return view;
    }
}
