package com.example.surepath.network;

import com.example.surepath.model.MessageResponse;
import com.example.surepath.model.StudentRegisterRequest;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {

    @POST("/student/register")
    Call<MessageResponse> registerStudent(
            @Body StudentRegisterRequest request
    );
}
