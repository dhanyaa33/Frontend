package com.example.surepath;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.surepath.model.MessageResponse;
import com.example.surepath.model.StudentRegisterRequest;
import com.example.surepath.network.ApiClient;
import com.example.surepath.network.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {

    // UI Components
    private EditText etName, etEmail, etPassword;
    private Button btnCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Bind views
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // Button click
        btnCreateAccount.setOnClickListener(v -> registerStudent());
    }

    private void registerStudent() {

        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Basic validation
        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create request body
        StudentRegisterRequest request = new StudentRegisterRequest(
                name,
                email,
                password,
                new String[]{"java"},     // demo skills
                "Urban",                  // demo district
                "General",                // demo category
                "chennai"                 // demo location
        );

        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        Call<MessageResponse> call = apiService.registerStudent(request);

        call.enqueue(new Callback<MessageResponse>() {
            @Override
            public void onResponse(Call<MessageResponse> call, Response<MessageResponse> response) {

                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(SignupActivity.this,
                            response.body().message,
                            Toast.LENGTH_LONG).show();

                    // TODO: Navigate to Login Screen
                    // startActivity(new Intent(SignupActivity.this, StudentLoginActivity.class));
                    // finish();

                } else {
                    Toast.makeText(SignupActivity.this,
                            "Signup failed",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<MessageResponse> call, Throwable t) {
                Log.e("SIGNUP_ERROR", t.getMessage());
                Toast.makeText(SignupActivity.this,
                        "Server error. Check backend.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
