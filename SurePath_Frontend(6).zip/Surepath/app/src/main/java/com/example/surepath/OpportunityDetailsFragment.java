package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OpportunityDetailsFragment extends Fragment {

    private RecyclerView rvRecentApplicants;
    private RecentApplicantsAdapter adapter;
    private List<RecentApplicantModel> applicantList;
    private Jobmodel job;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            job = (Jobmodel) getArguments().getSerializable("job");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_opportunity_details, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvJobTitle = view.findViewById(R.id.tvJobTitle);
        TextView tvCompanyAndLocation = view.findViewById(R.id.tvCompanyAndLocation);
        TextView tvApplicants = view.findViewById(R.id.tvApplicants);
        TextView tvViews = view.findViewById(R.id.tvViews);
        TextView tvPostedDate = view.findViewById(R.id.tvPostedDate);
        TextView tvOpeningsCount = view.findViewById(R.id.tvOpeningsCount);
        TextView tvFilledCount = view.findViewById(R.id.tvFilledCount);
        TextView tvRemainingCount = view.findViewById(R.id.tvRemainingCount);

        if (job != null) {
            tvJobTitle.setText(job.getTitle());
            tvCompanyAndLocation.setText(String.format(Locale.getDefault(), "%s Inc. • Mumbai", job.getCompany()));
            tvApplicants.setText(String.format(Locale.getDefault(), "%d Applicants", job.getApplicants()));
            // Dummy data for views and posted date as it is not in the model
            tvViews.setText("120 Views");
            tvPostedDate.setText("Posted 2d ago");

            // Dummy data for openings
            int openings = 5;
            int filled = 2;
            int remaining = openings - filled;
            tvOpeningsCount.setText(String.valueOf(openings));
            tvFilledCount.setText(String.valueOf(filled));
            tvRemainingCount.setText(String.valueOf(remaining));
        }

        rvRecentApplicants = view.findViewById(R.id.rvRecentApplicants);
        rvRecentApplicants.setLayoutManager(new LinearLayoutManager(getContext()));

        applicantList = new ArrayList<>();
        applicantList.add(new RecentApplicantModel("John Doe", 95));
        applicantList.add(new RecentApplicantModel("Sarah Smith", 88));
        applicantList.add(new RecentApplicantModel("Mike Johnson", 92));

        adapter = new RecentApplicantsAdapter(applicantList);
        rvRecentApplicants.setAdapter(adapter);
    }
}
