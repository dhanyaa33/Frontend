package com.example.surepath;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.ViewHolder> {

    private final List<Jobmodel> list;

    public JobAdapter(List<Jobmodel> list) {
        this.list = list;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, company, status, applicants;

        ViewHolder(View v) {
            super(v);
            title = v.findViewById(R.id.tvJobTitle);
            company = v.findViewById(R.id.tvCompany);
            status = v.findViewById(R.id.tvStatus);
            applicants = v.findViewById(R.id.tvApplicants);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_job, parent, false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int p) {
        Jobmodel m = list.get(p);
        h.title.setText(m.getTitle());
        h.company.setText(m.getCompany());
        h.status.setText(m.getStatus());
        h.applicants.setText(String.valueOf(m.getApplicants()));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
