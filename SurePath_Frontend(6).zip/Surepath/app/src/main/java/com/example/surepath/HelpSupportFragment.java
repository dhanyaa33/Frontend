package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HelpSupportFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_help_support, container, false);

        RecyclerView faqRecyclerView = view.findViewById(R.id.faqRecyclerView);
        faqRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        List<Faq> faqList = new ArrayList<>();
        faqList.add(new Faq(getString(R.string.faq_q1), getString(R.string.faq_a1)));
        faqList.add(new Faq(getString(R.string.faq_q2), getString(R.string.faq_a2)));
        faqList.add(new Faq(getString(R.string.faq_q3), getString(R.string.faq_a3)));
        faqList.add(new Faq(getString(R.string.faq_q4), getString(R.string.faq_a4)));

        FaqAdapter adapter = new FaqAdapter(faqList);
        faqRecyclerView.setAdapter(adapter);

        return view;
    }
}
