package com.example.surepath.model;

public class MessageResponse {
    public String message;
}
