package com.example.surepath;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CandidateAdapter extends RecyclerView.Adapter<CandidateAdapter.CandidateViewHolder> {

    private List<Candidate> candidateList;

    public CandidateAdapter(List<Candidate> candidateList) {
        this.candidateList = candidateList;
    }

    @NonNull
    @Override
    public CandidateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_candidate, parent, false);
        return new CandidateViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CandidateViewHolder holder, int position) {
        Candidate candidate = candidateList.get(position);
        holder.tvCandidateName.setText(candidate.getName());
        holder.tvCandidateRole.setText(candidate.getRole());
        holder.tvMatchScore.setText(String.format("%d%% Match", candidate.getMatchScore()));

        holder.itemView.setOnClickListener(v -> {
            AppCompatActivity activity = (AppCompatActivity) v.getContext();
            activity.getSupportFragmentManager().beginTransaction()
                    .replace(R.id.admin_fragment_container, CandidateDetailsFragment.newInstance(candidate))
                    .addToBackStack(null)
                    .commit();
        });
    }

    @Override
    public int getItemCount() {
        return candidateList.size();
    }

    static class CandidateViewHolder extends RecyclerView.ViewHolder {
        TextView tvCandidateName, tvCandidateRole, tvMatchScore;
        Button btnViewProfile;

        public CandidateViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCandidateName = itemView.findViewById(R.id.tvCandidateName);
            tvCandidateRole = itemView.findViewById(R.id.tvCandidateRole);
            tvMatchScore = itemView.findViewById(R.id.tvMatchScore);
            btnViewProfile = itemView.findViewById(R.id.btnViewProfile);
        }
    }
}
