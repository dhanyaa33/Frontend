package com.example.surepath;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class GovernmentSchemesFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_government_schemes, container, false);

        Toolbar toolbar = view.findViewById(R.id.toolbar);
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity) requireActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> getParentFragmentManager().popBackStack());

        RecyclerView schemesRecyclerView = view.findViewById(R.id.schemesRecyclerView);
        List<Scheme> schemeList = new ArrayList<>();
        // Add dummy data
        schemeList.add(new Scheme("Prime Minister Internship Scheme", "Ministry of Skill Development", "Government-funded internship program providing hands-on experience in various central government departments and PSUs.", "Active"));
        schemeList.add(new Scheme("National Apprenticeship Training Scheme", "Ministry of Labour & Employment", "Apprenticeship opportunities in manufacturing, engineering, and service sectors across India.", "Closing Soon"));
        schemeList.add(new Scheme("Digital India Internship Program", "Ministry of Electronics & IT", "Work on digital transformation projects, AI/ML initiatives, and government tech platforms.", "Upcoming"));
        schemeList.add(new Scheme("Startup India Internship", "DPIIT, Ministry of Commerce", "Internships with government-recognized startups across diverse sectors including fin-tech, health-tech, and ed-tech.", "Active"));

        SchemeAdapter adapter = new SchemeAdapter(schemeList);
        schemesRecyclerView.setAdapter(adapter);

        return view;
    }
}
