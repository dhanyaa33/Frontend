package com.example.surepath;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SkillOnboardingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_skill);

        TextView btnNext = findViewById(R.id.btnNext);
        TextView tvSkip = findViewById(R.id.tvSkip);

        btnNext.setOnClickListener(v -> {
            // Go to next onboarding OR login
            startActivity(new Intent(this, EasyPlacementActivity.class));
            finish();
        });

        tvSkip.setOnClickListener(v -> {
            startActivity(new Intent(this, EasyPlacementActivity.class));
            finish();
        });
    }
}